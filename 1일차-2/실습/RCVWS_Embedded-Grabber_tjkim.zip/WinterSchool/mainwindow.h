#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QImage>
#include <QLabel>

#include <sys/stat.h>
#include <sys/stat.h>

#include "camthread.h"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_mInit_clicked();

    void on_mConnect_clicked();

    void Display( QImage img );

    void on_mMac_cursorPositionChanged(int arg1, int arg2);

    void on_mIP_cursorPositionChanged(int arg1, int arg2);

    void on_mRecording_clicked();

    void on_lineEdit_editingFinished();

    void on_mFilePath_cursorPositionChanged(int arg1, int arg2);

    void on_mFilePath_returnPressed();

private:
    Ui::MainWindow *ui;

    void ShellScript();
    void CamInitialize(const char* Mac, const char* IpAdr);

    bool mDecoding;

    FILE* mFileStream;

    QString mCamMac;
    QString mCamIP;

    CamThread* mCamera;
};

#endif // MAINWINDOW_H
