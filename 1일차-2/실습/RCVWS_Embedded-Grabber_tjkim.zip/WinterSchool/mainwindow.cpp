#include "mainwindow.h"
#include "ui_mainwindow.h"

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

//    mCamMac = "00:b0:9d:be:70:50";
//    mCamIP = "169.254.0.9";

    mDecoding = false;

    mCamMac = "00:11:1c:02:92:81";
    mCamIP = "169.254.0.7";

    mCamera = new CamThread;

    connect( mCamera, SIGNAL( Display(QImage) ), this, SLOT( Display(QImage) ) );

}

MainWindow::~MainWindow()
{
    delete mCamera;
    delete ui;
}

void MainWindow::on_mInit_clicked()
{
    ShellScript();

    //Camera Ip congigure
    CamInitialize( mCamMac.toStdString().c_str(), mCamIP.toStdString().c_str() );
}

void MainWindow::on_mConnect_clicked()
{
    if ( !mCamera->mAcquisition )
    {
        if ( mCamera->Connect( mCamMac.toStdString().c_str() ) ) cout << "Connected" << endl;

        mCamera->mAcquisition = true;
        mCamera->start();

        ui->mConnect->setText("DisConnected");
    }
    else
    {
        mCamera->mAcquisition = false;

        mCamera->quit();
        mCamera->wait();

        if (!mCamera->DisConnect()) cout << "Disconnection failed" << endl;

        ui->mConnect->setText("Connected");
    }
}



void MainWindow::Display( QImage img )
{
    ui->mDisplay->setPixmap( QPixmap::fromImage( img.scaled( ui->mDisplay->width(), ui->mDisplay->height() ) ) );
}

void MainWindow::ShellScript()
{
    if (system("echo 'v1s10nlab2019' |"
               " sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_rp_filter.sh"
               " --mode=0 --restartnetworkstack=yes"))
    {
        cout << "set_rp_filter failed" << endl;
    }

    if (system("echo 'v1s10nlab2019' | sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_socket_buffer_size.sh"))
    {
        cout << "set_soket_buffer failed" << endl;
    }
    else cout << "set_soket_buffer" << endl;

    if (system("echo 'v1s10nlab2019' | sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_usbfs_memory_size.sh"))
    {
        cout << "set_usbfs_memory_size failed" << endl;
    }
    else cout << "set_usbfs_memory_size" << endl;
}

void MainWindow::CamInitialize(const char* Mac, const char* IpAdr)
{
    PvDeviceGEV* lDeviceSetIp = NULL;
    PvResult lResult;

    lResult = lDeviceSetIp->SetIPConfiguration( Mac, IpAdr, "255.255.0.0");

    if (!lResult.IsOK()) cout << lResult.GetCodeString().GetAscii() << endl;

}


void MainWindow::on_mMac_cursorPositionChanged(int arg1, int arg2)
{
    mCamMac = ui->mMac->text();
}

void MainWindow::on_mIP_cursorPositionChanged(int arg1, int arg2)
{
    mCamIP = ui->mIP->text();
}

void MainWindow::on_mRecording_clicked()
{
    if ( mCamera->mAcquisition && !mCamera->mRecording)
    {
        mCamera->mRecording = true;

        ui->mRecording->setText("Stop Recording");
    }
    else
    {
       mCamera->mRecording = false;

       fclose( mCamera->mFileStream );

       //mDecoding = true;

       ui->mRecording->setText("Recording");
    }
}

void MainWindow::on_mFilePath_returnPressed()
{
    mCamera->mFileStream = fopen( ui->mFilePath->text().toStdString().c_str(), "wb" );
    cout << ui->mFilePath->text().toStdString().c_str() << endl;

    if ( mDecoding )
    {
        QString Path = ui->mFilePath->text();

        mFileStream = fopen( Path.toStdString().c_str(), "rb" );

        QString SaveImg = Path.section( "/", 0, -2 );
        SaveImg.append("/img");

        mkdir( SaveImg.toStdString().c_str(), 777 );


    }
}

void MainWindow::on_lineEdit_editingFinished()
{
    //mCamera->mFilePath = ui->mFilePath->text().toStdString().c_str();

}

void MainWindow::on_mFilePath_cursorPositionChanged(int arg1, int arg2)
{

}
