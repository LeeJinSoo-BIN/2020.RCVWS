#include "camthread.h"

using namespace std;

CamThread::CamThread(QObject *parent) : QThread(parent)
{
    mDevice = NULL;
    mDeviceGEV = NULL;
    mStream = NULL;
    mStreamGEV = NULL;
    mPipeline = NULL;

    mAcquisition = false;
    mRecording = false;

}

void CamThread::run()
{
    cout << "HI" << endl;

    if ( mDeviceGEV == NULL ) cout << "mDeviceGEV NULL..." << endl;
    if ( mStreamGEV == NULL ) cout << "mStreamGEV NULL..." << endl;
    if ( mPipeline == NULL ) cout << "mPipeline NULL..." << endl;

    AcquireImages( mDeviceGEV, mPipeline, mStreamGEV );
}

void CamThread::AcquireImages(PvDeviceGEV *Device, PvPipeline *Pipeline, PvStreamGEV *Stream)
{
    // Get device parameters need to control streaming
    PvGenParameterArray *lDeviceParams = Device->GetParameters();

//    //////////////////Thermal Setting
//    lDeviceParams->SetEnumValue("SyncMode", 1);
//    lDeviceParams->SetEnumValue("NUCMode", 0);
//    ///////////////////////////////////////////////
//    //////////////////RGB Setting
//    lDeviceParams->SetEnumValue("ExposureAuto",0);

//    lDeviceParams->SetFloatValue("ExposureTime",1050);
//    lDeviceParams->SetEnumValue("TriggerMode",1);
//    lDeviceParams->SetEnumValue("TriggerSource",3);

//    lDeviceParams->SetIntegerValue("OffsetX",0);
//    lDeviceParams->SetIntegerValue("OffsetY",0);
//    lDeviceParams->SetIntegerValue("Width",1288);
//    lDeviceParams->SetIntegerValue("Height",964);
//    ////////////////////////////////////////////////

    // Map the GenICam AcquisitionStart and AcquisitionStop commands
    PvGenCommand *lStart = dynamic_cast<PvGenCommand *>( lDeviceParams->Get( "AcquisitionStart" ) );
    PvGenCommand *lStop = dynamic_cast<PvGenCommand *>( lDeviceParams->Get( "AcquisitionStop" ) );

    // Enable streaming and send the AcquisitionStart command
    cout << "Enabling streaming and sending AcquisitionStart command." << endl;
    Device->StreamEnable();
    lStart->Execute();

    cout << endl << "<Start>" << endl;

    PvResult Result;

    PvBuffer* Buffer;

    while( mAcquisition )
    {
        QImage qimg;
        Buffer = NULL;

        if (Stream->IsOpen() && Pipeline->IsStarted())
        {
            Result = Pipeline->RetrieveNextBuffer( &Buffer, 0xFFFFFFFF, &Result);

            if( !Result.IsOK() ) continue;
        }

        uint32_t width = Buffer->GetImage()->GetWidth();
        uint32_t height = Buffer->GetImage()->GetHeight();

        if ( width != 0)
        {
            uint32_t size = Buffer->GetSize();

            cv::Mat img_C1( height, width, CV_8UC1 );

            memcpy( img_C1.data, Buffer->GetDataPointer(), size );

            if ( width > 320 )  //RGB
            {
                cv::Mat img( 964, 1288, CV_8UC3 );
                cv::cvtColor( img_C1, img, cv::COLOR_BayerGB2BGR);

                if ( mRecording ) fwrite( img.data, sizeof(uchar), img.cols * img.rows * 3, mFileStream );

                qimg = mat_to_qimage_cpy( img, QImage::Format_RGB888 );

            }
            else        //Thermal
            {
                if ( mRecording ) fwrite( img_C1.data, sizeof(uchar), img_C1.cols * img_C1.rows, mFileStream );

                qimg = mat_to_qimage_cpy( img_C1, QImage::Format_Grayscale8 );
            }

            emit Display( qimg );


            Result = Pipeline->ReleaseBuffer( Buffer );
            if (!Result.IsOK()) cout << "Can't ReleaseBuffer" << endl;

        }
    }

    lStop->Execute();
    Device->StreamDisable();
    Stream->AbortQueuedBuffers();

}

bool CamThread::Connect(const char* Mac)
{
    mDevice = ConnectToDevice(Mac);

    mDeviceGEV = dynamic_cast<PvDeviceGEV *>( mDevice );

    if ( mDevice != NULL )
    {
        mStream = OpenStream( mDeviceGEV->GetIPAddress() );

        if (mStream != NULL)
        {
            mStreamGEV = ConfigureStream(mDevice, mStream);

            mPipeline = MakePipeline( mDeviceGEV, mStream );

            if ( mPipeline == NULL ) return false;

        }
        else
        {
            cout << "Disable to stream from camera" << endl;

            return false;
        }
    }
    else
    {
        cout << "Disable to connect to camera" << endl;

        return false;
    }

    return true;
}

bool CamThread::DisConnect()
{
    if ( mPipeline != NULL )
    {
        cout << "Delete Pipeline" << endl;
        delete mPipeline;

        if ( mStream != NULL )
        {
            cout << "Closing stream" << endl;
            mStream->Close();
            PvStream::Free( mStream );

            if ( mDevice != NULL )
            {
                cout << "Disconnecting device" << endl;
                mDevice->Disconnect();
                PvDevice::Free( mDevice);
            }
            else   return false;
        }
        else return false;
    }
    else return false;

    return true;
}

PvDevice* CamThread::ConnectToDevice( const char* aConnectionID)
{
    PvDevice *lDevice;
    PvResult lResult;

    // Connect to the GigE Vision or USB3 Vision device
    cout << "Connecting to device." << endl;
    lDevice = PvDevice::CreateAndConnect( aConnectionID, &lResult );
    if ( lDevice == NULL )
    {
        cout << "Unable to connect to device: "
        << lResult.GetCodeString().GetAscii()
        << " ("
        << lResult.GetDescription().GetAscii()
        << ")" << endl;
    }


    return lDevice;
}

PvStream* CamThread::OpenStream( const PvString &aConnectionID )
{
    PvStream *lStream;
    PvResult lResult;

    // Open stream to the GigE Vision or USB3 Vision device
    cout << "Opening stream from device." << endl;
    lStream = PvStream::CreateAndOpen( aConnectionID, &lResult );
    if ( lStream == NULL )
    {
        cout << "Unable to stream from device. "
            << lResult.GetCodeString().GetAscii()
            << " ("
            << lResult.GetDescription().GetAscii()
            << ")"
            << endl;
    }

    return lStream;
}

PvStreamGEV* CamThread::ConfigureStream( PvDevice *aDevice, PvStream *aStream  )
{
    PvStreamGEV* lStreamGEV = NULL;
    // If this is a GigE Vision device, configure GigE Vision specific streaming parameters
    PvDeviceGEV* lDeviceGEV = dynamic_cast<PvDeviceGEV *>( aDevice );
    if ( lDeviceGEV != NULL )
    {
        lStreamGEV = static_cast<PvStreamGEV *>( aStream );

        // Negotiate packet size
        lDeviceGEV->NegotiatePacketSize();

        // Configure device streaming destination
        lDeviceGEV->SetStreamDestination( lStreamGEV->GetLocalIPAddress(), lStreamGEV->GetLocalPort() );
    }

    return lStreamGEV;
}

PvPipeline *CamThread::MakePipeline( PvDeviceGEV *aDevice, PvStream *aStream)
{

    PvResult lResult;

    // Reading payload size from device
    uint32_t lSize = aDevice->GetPayloadSize();

   PvPipeline *mPipeline;

    mPipeline = new PvPipeline(aStream); //lStream??

    mPipeline->SetBufferSize(static_cast<uint32_t>(lSize));
    mPipeline->SetBufferCount( 16 );
    lResult = mPipeline->Start();
    if (!lResult.IsOK())
    {
        cout << "Unable to start pipeline" << endl;
    }

    PvGenBoolean *lRequestMissingPackets = dynamic_cast<PvGenBoolean *>(aStream->GetParameters()->GetBoolean("RequestMissingPackets"));
    if ((lRequestMissingPackets != NULL) && lRequestMissingPackets->IsAvailable())
    {
        // Disabling request missing packets.
        lRequestMissingPackets->SetValue(false);
    }

    return mPipeline;

}

QImage CamThread::mat_to_qimage_cpy(cv::Mat const &mat,
                         QImage::Format format)
{
    return QImage(mat.data, mat.cols, mat.rows,
                  mat.step, format).copy();
}

cv::Mat CamThread::qimage_to_mat_cpy(QImage const &img, int format)
{
    return cv::Mat(img.height(), img.width(), format,
                   const_cast<uchar*>(img.bits()),
                   img.bytesPerLine()).clone();
}

QImage CamThread::Buffer_to_qimage_cpy(PvBuffer* const &buffer, QImage::Format format, uint32_t size)
{
    return QImage(const_cast<uchar*>(buffer->GetDataPointer()), (int)buffer->GetImage()->GetWidth(),
                  (int)buffer->GetImage()->GetHeight(), format).copy();
}
