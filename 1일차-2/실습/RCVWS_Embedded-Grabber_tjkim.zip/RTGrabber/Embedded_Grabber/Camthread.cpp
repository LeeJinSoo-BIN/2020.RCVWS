#include "camthread.h"


using namespace std;

//PvDevice *CamThread::ConnectToDevice( const char* aConnectionID);
//PvStream *CamThread::OpenStream( const PvString &aConnectionID );
//PvStreamGEV* CamThread::ConfigureStream( PvDevice *aDevice, PvStream *aStream );
//PvPipeline *CamThread::MakePipeline( PvDeviceGEV *aDevice, PvStream *aStream);
//void CamThread::AcquireImages( PvDeviceGEV *aDevice_T, PvPipeline *mPipeline_T, PvStreamGEV *aStream_T, PvDeviceGEV *aDevice_R, PvPipeline *mPipeline_R, PvStreamGEV *aStream_R );
//bool CamThread::zConnect(const char* Mac);
//bool CamThread::zDisConnect();

CamThread::CamThread(QObject *parent) : QThread(parent)
{

    mDevice = NULL;
    mDeviceGEV = NULL;
    mStream = NULL;
    mStreamGEV = NULL;
    mPipeline = NULL;

    mDeviceGEV2 = NULL;
    mStreamGEV2 = NULL;
    mPipeline2 = NULL;


}

void CamThread::run()
{
    cout << "HI" << endl;

    if ( mDeviceGEV == NULL ) cout << "mDeviceGEV NULL..." << endl;
    if ( mStreamGEV == NULL ) cout << "mStreamGEV NULL..." << endl;
    if ( mPipeline == NULL ) cout << "mPipeline NULL..." << endl;
    if ( mDeviceGEV2 == NULL ) cout << "mDeviceGEV2 NULL..." << endl;
    if ( mStreamGEV2 == NULL ) cout << "mStreamGEV2 NULL..." << endl;
    if ( mPipeline2 == NULL ) cout << "mPipeline2 NULL..." << endl;

    AcquireImages( mDeviceGEV, mPipeline, mStreamGEV, mDeviceGEV2, mPipeline2, mStreamGEV2 );
}

void CamThread::RectiParams()
{
    cv::FileStorage fs("/home/rcvsejong/Desktop/warpEbedded_Grabber/rrParams.xml", cv::FileStorage::READ);
    cv::FileNode node1 = fs["CameraParameters1"];
    node1["DistCoefficients"] >> mDistCoeffsRR[0];
    node1["IntrinsicMatrix"] >> mCameraMatrixRR[0];
    cv::FileNode node2 = fs["CameraParameters2"];
    node2["DistCoefficients"] >> mDistCoeffsRR[1];
    node2["IntrinsicMatrix"] >> mCameraMatrixRR[1];
    fs["RotationOfCamera2"] >> mRotationRR;
    fs["TranslationOfCamera2"] >> mTranslationRR;
    fs.release();

    //cv::FileStorage fsT("/home/rcvsejong/Desktop/warpEbedded_Grabber/rtParams.xml", cv::FileStorage::READ);
    cv::FileStorage fsT("/home/rcvsejong/Desktop/warpEbedded_Grabber/rtParams(RT__).xml", cv::FileStorage::READ);


    cv::FileNode node1T = fsT["CameraParameters1"];
    node1T["DistCoefficients"] >> mDistCoeffsRT[0];
    node1T["IntrinsicMatrix"] >> mCameraMatrixRT[0];
    cv::FileNode node2T = fsT["CameraParameters2"];
    node2T["DistCoefficients"] >> mDistCoeffsRT[1];
    node2T["IntrinsicMatrix"] >> mCameraMatrixRT[1];
    fsT["RotationOfCamera2"] >> mRotationRT;
    fsT["TranslationOfCamera2"] >> mTranslationRT;
    fsT.release();

    //cv::transpose( mRotationRR, mRotationRR );
    //cv::transpose( mRotationRT, mRotationRT );

/*
    cv::stereoRectify( mCameraMatrixRR[0], mDistCoeffsRR[0],
        mCameraMatrixRR[1], mDistCoeffsRR[1],
        cv::Size(640, 512), mRotationRR, mTranslationRR, mR1_rr, mR2_rr, mP1_rr, mP2_rr, mQ_rr,
        cv::CALIB_ZERO_DISPARITY, 0.17, cv::Size(640, 512) );
*/

    cv::stereoRectify( mCameraMatrixRT[0], mDistCoeffsRT[0],
        mCameraMatrixRT[1], mDistCoeffsRT[1],
        cv::Size(640, 512), mRotationRT, mTranslationRT, mR1_rt, mR2_rt, mP1_rt, mP2_rt, mQ_rt,
        cv::CALIB_ZERO_DISPARITY, 0.17, cv::Size(640, 512));



    cv::initUndistortRectifyMap(mCameraMatrixRT[0], mDistCoeffsRT[0],
            mR1_rt, mP1_rt, cv::Size(640, 512), CV_32F, mrtmap[0][0], mrtmap[0][1]);
    cv::initUndistortRectifyMap(mCameraMatrixRT[1], mDistCoeffsRT[1],
            mR2_rt, mP2_rt, cv::Size(640, 512), CV_32F, mrtmap[1][0], mrtmap[1][1]);

}

vector<float> csv_read_row(istream &file, char delimiter);
vector<float> csv_read_row(istream &file, char delimiter)
{
    stringstream ss;
    bool inquotes = false;
    float num;
    vector<float> row;
    while (file.good())
    {
        char c = file.get();
        if (!inquotes &&c == '"')
            inquotes = true;
        else if (inquotes && c == '"')
        {
            if (file.peek() == '"')
                ss << (char)file.get();
            else
                inquotes = false;
        }
        else if (!inquotes && c == delimiter)
        {
            ss >> num;
            row.push_back(num);
            ss.clear();
        }
        else if (!inquotes && (c == '\r' || c == '\n'))
        {
            if (file.peek() == '\n') { file.get(); }
            ss >> num;
            row.push_back(num);
            return row;
        }
        else
            ss << c;
    }
}


void CamThread::AcquireImages( PvDeviceGEV *aDevice_T, PvPipeline *mPipeline_T, PvStreamGEV *aStream_T, PvDeviceGEV *aDevice_R, PvPipeline *mPipeline_R, PvStreamGEV *aStream_R )
{

    PvBufferConverter *lConveterR;
    PvBufferConverter *lConveterT;

    vector<cv::Point2f> pst_src, pst_dst;
       //-------------Load_coordinate--------------------
       ifstream file("/home/rcvsejong/Desktop/warpEbedded_Grabber/hmgrp_pts1.csv");
       if (file.fail())
           (cout << "No existing file!" << endl);
       while (file.good())
       {
           vector<float> row = csv_read_row(file, ',');
           //cout << row[0] << row[1] << row[2] << row[3] << endl;
           pst_src.push_back(cv::Point2f(row[0],row[1]));//rgb
           pst_dst.push_back(cv::Point2f(row[2],row[3]));//thermal
       }

    mHomography = cv::findHomography(pst_dst, pst_src);
       //----------------------------------------------------

    // Get device parameters need to control streaming
    PvGenParameterArray *lDeviceParams_T = aDevice_T->GetParameters();
    PvGenParameterArray *lDeviceParams_R = aDevice_R->GetParameters();
    //////////////////Thermal Setting
    lDeviceParams_T->SetEnumValue("SyncMode", 1);
    lDeviceParams_T->SetEnumValue("NUCMode", 0);
    ///////////////////////////////////////////////
    //////////////////RGB Setting
    lDeviceParams_R->SetEnumValue("ExposureAuto",0);

    lDeviceParams_R->SetFloatValue("ExposureTime",1050);
    lDeviceParams_R->SetEnumValue("TriggerMode",1);
    lDeviceParams_R->SetEnumValue("TriggerSource",3);

    lDeviceParams_R->SetIntegerValue("OffsetX",0);
    lDeviceParams_R->SetIntegerValue("OffsetY",0);
    lDeviceParams_R->SetIntegerValue("Width",1288);
    lDeviceParams_R->SetIntegerValue("Height",964);
    ////////////////////////////////////////////////


    cout << "Setting Complete" << endl;

    // Map the GenICam AcquisitionStart and AcquisitionStop commands
    PvGenCommand *lStart_T = dynamic_cast<PvGenCommand *>( lDeviceParams_T->Get( "AcquisitionStart" ) );
    PvGenCommand *lStop_T = dynamic_cast<PvGenCommand *>( lDeviceParams_T->Get( "AcquisitionStop" ) );

    PvGenCommand *lStart_R = dynamic_cast<PvGenCommand *>( lDeviceParams_R->Get( "AcquisitionStart" ) );
    PvGenCommand *lStop_R = dynamic_cast<PvGenCommand *>( lDeviceParams_R->Get( "AcquisitionStop" ) );
    // Get stream parameters
    PvGenParameterArray *lStreamParams_T = aStream_T->GetParameters();
    PvGenParameterArray *lStreamParams_R = aStream_R->GetParameters();

    // Map a few GenICam stream stats counters
    PvGenFloat *lFrameRate_T = dynamic_cast<PvGenFloat *>( lStreamParams_T->Get( "AcquisitionRate" ) );
    PvGenFloat *lBandwidth_T = dynamic_cast<PvGenFloat *>( lStreamParams_T->Get( "Bandwidth" ) );
    PvGenFloat *lFrameRate_R = dynamic_cast<PvGenFloat *>( lStreamParams_R->Get( "AcquisitionRate" ) );
    PvGenFloat *lBandwidth_R = dynamic_cast<PvGenFloat *>( lStreamParams_R->Get( "Bandwidth" ) );

    // Enable streaming and send the AcquisitionStart command
    cout << "Enabling streaming and sending AcquisitionStart command." << endl;
    aDevice_T->StreamEnable();
    lStart_T->Execute();

    aDevice_R->StreamEnable();
    lStart_R->Execute();

    char lDoodle[] = "|\\-|-/";
    int lDoodleIndex = 0;
    double lFrameRateVal_T = 0.0;
    double lBandwidthVal_T = 0.0;
    double lFrameRateVal_R = 0.0;
    double lBandwidthVal_R = 0.0;


    //cout << "Acquire image" << endl;

    // Acquire images until the user instructs us to stop.
    //cout << endl << "<press a key to stop streaming>" << endl;
    cout << endl << "<Start>" << endl;


    //----------Rectify----------------

    RectiParams();

    //-------------cudaStreoBM---------------
   // cv::Ptr<cv::cuda::StereoBM> bm;
    //int ndisp = 256;

    //bm = cv::cuda::createStereoBM(ndisp);


    //--------------------

    while(mAcqusition)
    {
        //cout << "OK" << endl;
        lBuffer_T = NULL;
        lBuffer_R = NULL;

        PvResult lOperationResult_T;
        PvResult lOperationResult_R;

        PvResult lResult_T;
        PvResult lResult_R ;

       // mMutex.lock();

        if ((aStream_T != NULL) && aStream_T->IsOpen() &&
                (mPipeline_T != NULL) && mPipeline_T->IsStarted())
        {
            //cout<<"Get Thermal"<<endl;
            lResult_T = mPipeline_T->RetrieveNextBuffer( &lBuffer_T, 0xFFFFFFFF, &lOperationResult_T);
            //cout << lResult_T.GetCodeString().GetAscii() << endl;

        }
        else{
           // cout<<"Pass Thermal"<<endl;
            continue;
        }


        if ((aStream_R != NULL) && aStream_R->IsOpen() &&
                (mPipeline_R != NULL) && mPipeline_R->IsStarted())
        {
            //cout<<"Get RGB"<<endl;
            lResult_R = mPipeline2->RetrieveNextBuffer( &lBuffer_R, 0xFFFFFFFF, &lOperationResult_R );
            //cout << lResult_T.GetCodeString().GetAscii() << endl;
        }
        else{
            //cout<<"Pass RGB"<<endl;
            continue;
        }



        if ( lResult_T.IsOK() && lResult_R.IsOK() && lBuffer_T->GetImage()->GetWidth() != 0 && lBuffer_R->GetImage()->GetWidth() != 0  )
        {
           // cout<<"Pass"<<endl;
            if (  lOperationResult_R.IsOK() && lOperationResult_T.IsOK() )
            {
               // cout<<"Pass"<<endl;

                lFrameRate_T->GetValue( lFrameRateVal_T );
                lBandwidth_T->GetValue( lBandwidthVal_T );

                lFrameRate_R->GetValue( lFrameRateVal_R );
                lBandwidth_R->GetValue( lBandwidthVal_R );

                uint32_t size_T = lBuffer_T->GetSize();

                cv::Mat MatThermal(256, 320, CV_8UC1);
                cv::Mat MatThermal_resize(512, 640, CV_8UC1);

               // mMutex.lock();

                memcpy(MatThermal.data, lBuffer_T->GetDataPointer(), size_T);

                cv::resize(MatThermal, MatThermal_resize, cv::Size(640, 512));

//------------------------------------------------------------


                uint32_t size_R = lBuffer_R->GetSize();

                cv::Mat Img_R(964, 1288, CV_8UC3);
                cv::Mat Img_R_1(964, 1288, CV_8UC1);

                cv::Mat Img_R_resize(512, 640, CV_8UC3);
                memcpy(Img_R_1.data, lBuffer_R->GetDataPointer(), size_R);
                //memcpy(Img_R.data, new_RGB->GetDataPointer(), size_R);

                cv::cvtColor(Img_R_1,Img_R, cv::COLOR_BayerGB2BGR);

                cv::resize(Img_R, Img_R_resize, cv::Size(640, 512));

                //-----rectify-------------      

                cv::remap(MatThermal_resize, MatThermal_resize, mrtmap[1][0], mrtmap[1][1], cv::INTER_LINEAR);

                cv::remap(Img_R_resize, Img_R_resize, mrtmap[0][0], mrtmap[0][1], cv::INTER_LINEAR);

                //-------------------------

                //------------------image warping-----------------------------------------------

                cv::Mat warpThermal;

                cv::warpPerspective( MatThermal_resize, warpThermal, mHomography, cv::Size(640,512),cv::INTER_LINEAR );
                cv::Mat RGBC1(cv::Size(640,512), CV_8UC1);
                cv::cvtColor(Img_R_resize, RGBC1, cv::COLOR_RGB2GRAY);


                cv::Mat Origin, PW;

                cv::addWeighted(RGBC1,0.5,MatThermal_resize,0.5,0,Origin);
                                cv::addWeighted(RGBC1,0.5,warpThermal,0.5,0,PW);

                //------------------------------------------------------------------------------------------

                QImage qimg_t = mat_to_qimage_cpy( MatThermal_resize, QImage::Format_Grayscale8 );

                //QImage qimg_r = mat_to_qimage_cpy(Img_R_resize, QImage::Format_RGB888);
                QImage qimg_r = mat_to_qimage_cpy( PW, QImage::Format_Grayscale8 );

                //mMutex.unlock();

              //  emit RGB_img( qimg_r );

                //emit ALL_IMAGE( qimg_r, qimg_t );

                cv::cvtColor(Img_R, Img_R, cv::COLOR_BGR2RGB);

                //-----------emit-Signal---------------------------------

                emit Display( qimg_r, qimg_t );

                emit ALL_IMAGE( Img_R_resize, MatThermal_resize );
/*
                //-------------------------------------------------------

                cv::cuda::GpuMat d_left, d_right;

                cv::cvtColor(Img_R_resize, Img_R_resize, cv::COLOR_BGR2GRAY);
                //cv::cvtColor(right_src, right, COLOR_BGR2GRAY);

                d_left.upload(Img_R_resize);
                d_right.upload(MatThermal_resize);


                // Prepare disparity map of specified type
                cv::Mat disp(Img_R_resize.size(), CV_8U);
                cv::cuda::GpuMat d_disp(Img_R_resize.size(), CV_8U);

                cout << endl;

                bm->compute(d_left, d_right, d_disp);



                  // Show results
                d_disp.download(disp);

                cv::Mat cm_img0;
                // Apply the colormap:
                cv::applyColorMap(disp, cm_img0, cv::COLORMAP_RAINBOW);

                cv::Mat norm;

                cv::normalize(cm_img0, norm, 50, 255, cv::NORM_MINMAX);

                cv::imwrite("/home/rcvsejong/Pictures/color_disparity.jpg", norm);

                QImage qimg_disp(norm.data, norm.cols, norm.rows, norm.step, QImage::Format_RGB888);
*/
                //if (mRectify)   emit Disp( qimg_t, qimg_r); //emit Disp( qimg_disp );

                //-------------------------------------------------------

                //```````

                lResult_T = mPipeline_T->ReleaseBuffer(lBuffer_T);
                if (!lResult_T.IsOK()) cout << "Can't ReleaseBuffer" << endl;

                lBuffer_T = NULL;

                lResult_R = mPipeline_R->ReleaseBuffer(lBuffer_R);
                if (!lResult_R.IsOK()) cout << "Can't ReleaseBuffer" << endl;

                lBuffer_R = NULL;

                //````````

                //~~~~~~~

            }
            else
            {
                // Non OK operational result
               // cout << lDoodle[ lDoodleIndex ] << " operational_T ERROR!! " << lOperationResult_T.GetCodeString().GetAscii() << "\r";
               // cout << lDoodle[ lDoodleIndex ] << " operational_R ERROR!! " << lOperationResult_R.GetCodeString().GetAscii() << "\r";
            }

            // Re-queue the buffer in the stream object
            //aStream_T->QueueBuffer( lBuffer_T );
            //aStream_R->QueueBuffer( lBuffer_R );
        }
        else
        {
            // Retrieve buffer failure
           //cout << lDoodle[ lDoodleIndex ] << " Retrieve buffer ERROR! " << lResult_T.GetCodeString().GetAscii()
                 //<< " " << lResult_R.GetCodeString().GetAscii() << "\r";
         //   cout << lDoodle[ lDoodleIndex ] << " Retrieve buffer ERROR! " << lResult_T.GetCodeString().GetAscii()
           //      << " " << lResult_R.GetCodeString().GetAscii() << "\r";

        }

        ++lDoodleIndex %= 6;
    }


    //---------------------------------------------------------------------
    //PvGetChar(); // Flush key buffer for next stop.
  //  cout << endl << endl;

    // Tell the device to stop sending images.
    cout << "Sending AcquisitionStop command to the device" << endl;
    lStop_T->Execute();
    lStop_R->Execute();

    // Disable streaming on the device
    cout << "Disable streaming on the controller." << endl;
    aDevice_T->StreamDisable();
    aDevice_R->StreamDisable();

    // Abort all buffers from the stream and dequeue
    cout << "Aborting buffers still in stream" << endl;
    aStream_T->AbortQueuedBuffers();
    aStream_R->AbortQueuedBuffers();

    //lBuffer_T->Free();
    //lBuffer_R->Free();


}

bool CamThread::zConnect(const char* Mac)
{
    mDevice = ConnectToDevice(Mac);

    mDeviceGEV = dynamic_cast<PvDeviceGEV *>( mDevice );

    if ( mDevice != NULL )
    {
        mStream = OpenStream( mDeviceGEV->GetIPAddress() );

        if (mStream != NULL)
        {
            mStreamGEV = ConfigureStream(mDevice, mStream);

            mPipeline = MakePipeline( mDeviceGEV, mStream );

            if ( mPipeline == NULL ) return false;

        }
        else
        {
            cout << "Disable to stream from camera" << endl;

            return false;
        }
    }
    else
    {
        cout << "Disable to connect to camera" << endl;

        return false;
    }

    return true;
}

bool CamThread::zDisConnect()
{
    if ( mPipeline != NULL )
    {
        cout << "Delete Pipeline" << endl;
        delete mPipeline;

        if ( mStream != NULL )
        {
            cout << "Closing stream" << endl;
            mStream->Close();
            PvStream::Free( mStream );

            if ( mDevice != NULL )
            {
                cout << "Disconnecting device" << endl;
                mDevice->Disconnect();
                PvDevice::Free( mDevice);
            }
            else   return false;
        }
        else return false;
    }
    else return false;

    return true;
}

PvDevice* CamThread::ConnectToDevice( const char* aConnectionID)
{
    PvDevice *lDevice;
    PvResult lResult;

    // Connect to the GigE Vision or USB3 Vision device
    cout << "Connecting to device." << endl;
    lDevice = PvDevice::CreateAndConnect( aConnectionID, &lResult );
    if ( lDevice == NULL )
    {
        cout << "Unable to connect to device: "
        << lResult.GetCodeString().GetAscii()
        << " ("
        << lResult.GetDescription().GetAscii()
        << ")" << endl;
    }


    return lDevice;
}

PvStream* CamThread::OpenStream( const PvString &aConnectionID )
{
    PvStream *lStream;
    PvResult lResult;

    // Open stream to the GigE Vision or USB3 Vision device
    cout << "Opening stream from device." << endl;
    lStream = PvStream::CreateAndOpen( aConnectionID, &lResult );
    if ( lStream == NULL )
    {
        cout << "Unable to stream from device. "
            << lResult.GetCodeString().GetAscii()
            << " ("
            << lResult.GetDescription().GetAscii()
            << ")"
            << endl;
    }

    return lStream;
}

PvStreamGEV* CamThread::ConfigureStream( PvDevice *aDevice, PvStream *aStream  )
{
    PvStreamGEV* lStreamGEV = NULL;
    // If this is a GigE Vision device, configure GigE Vision specific streaming parameters
    PvDeviceGEV* lDeviceGEV = dynamic_cast<PvDeviceGEV *>( aDevice );
    if ( lDeviceGEV != NULL )
    {
        lStreamGEV = static_cast<PvStreamGEV *>( aStream );

        // Negotiate packet size
        lDeviceGEV->NegotiatePacketSize();

        // Configure device streaming destination
        lDeviceGEV->SetStreamDestination( lStreamGEV->GetLocalIPAddress(), lStreamGEV->GetLocalPort() );
    }

    return lStreamGEV;
}

PvPipeline *CamThread::MakePipeline( PvDeviceGEV *aDevice, PvStream *aStream)
{

    PvResult lResult;

    // Reading payload size from device
    uint32_t lSize = aDevice->GetPayloadSize();

   PvPipeline *mPipeline;

    mPipeline = new PvPipeline(aStream); //lStream??

    mPipeline->SetBufferSize(static_cast<uint32_t>(lSize));
    mPipeline->SetBufferCount( 16 );
    lResult = mPipeline->Start();
    if (!lResult.IsOK())
    {
        cout << "Unable to start pipeline" << endl;
    }

    PvGenBoolean *lRequestMissingPackets = dynamic_cast<PvGenBoolean *>(aStream->GetParameters()->GetBoolean("RequestMissingPackets"));
    if ((lRequestMissingPackets != NULL) && lRequestMissingPackets->IsAvailable())
    {
        // Disabling request missing packets.
        lRequestMissingPackets->SetValue(false);
    }

    return mPipeline;

}

QImage CamThread::mat_to_qimage_cpy(cv::Mat const &mat,
                         QImage::Format format)
{
    return QImage(mat.data, mat.cols, mat.rows,
                  mat.step, format).copy();
}

cv::Mat CamThread::qimage_to_mat_cpy(QImage const &img, int format)
{
    return cv::Mat(img.height(), img.width(), format,
                   const_cast<uchar*>(img.bits()),
                   img.bytesPerLine()).clone();
}

QImage CamThread::Buffer_to_qimage_cpy(PvBuffer* const &buffer, QImage::Format format, uint32_t size)
{
    return QImage(const_cast<uchar*>(buffer->GetDataPointer()), (int)buffer->GetImage()->GetWidth(),
                  (int)buffer->GetImage()->GetHeight(), format).copy();
}

