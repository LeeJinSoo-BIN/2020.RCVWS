#ifndef AFMODEL_H
#define AFMODEL_H

#include <iostream>

#undef slots
#include <torch/torch.h>
#include <torch/script.h>
#include <torch/nms/cuda/nms_cuda.h>

#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <string.h>
#include <cmath>
#include <time.h>
#include <map>
#include <memory.h>
#include <ctime>
#include <vector>
#include <cstdarg>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <cuda_runtime.h>

//#include <nms_cpu.hpp>
#define slots Q_SLOTS


class AfModel
{
public:
    AfModel();

    bool creat( const char* );
    bool run( cv::Mat *dstRGB, cv::Mat *dstThermal, cv::Mat &RGB, cv::Mat &Thermal );
    bool run( cv::Mat &RGB, cv::Mat &Thermal, cv::Rect point );


private:
    std::shared_ptr<torch::jit::script::Module> mModuleBefore, mModuleAfter;
    torch::Tensor mPriors_xy, mDetect_loc, mDetect_score;

    torch::Tensor create_prior_boxes();
};

#endif // AFMODEL_H
