#include "mainwindow.h"
#include <QApplication>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    //fork();
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
