#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "camthread.h"

#include <QMainWindow>
#include <QImage>
#include <QLabel>

#include <iostream>

using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    bool mDisplay;
    bool mRecording;
    bool mDecoding;
    int num;

    QString mRGBMac;
    QString mRGBIp;

    QString mThermalMac;
    QString mThermalIp;

    FILE* mFileStream;

private slots:

    void on_m_connected_clicked();
    void on_m_initialize_clicked();

    void Display_RGB( QImage rgb );
    void Display_Thermal( QImage qimg_t );

    void SlotDisplay( QImage rgb, QImage ther );

    void Recording(cv::Mat RGB, cv::Mat Theraml );

    //void Recording(QImage RGB, QImage Theraml );

    void Display_Disp( QImage Disp );

    void EedDecodeSetText( int eof );

    //void Display_Disp( QImage T, QImage R );

    void on_mDisplay_clicked();

    void on_mRGBMac_editingFinished();

    void on_mRGBIP_editingFinished();

    void on_mThermalMac_editingFinished();

    void on_mThermalIP_editingFinished();

    void on_m_recording_clicked();

    void on_mDecoding_clicked();

private:
    Ui::MainWindow *ui;
    void ShellScript();
    void CamInitialize(const char* Mac, const char* IpAdr);
    void Decoding();

    QLabel* mRGB;
    QLabel* mThermal;

    CamThread* mCamera[2];

    FileThread* mFilethread;

};

#endif // MAINWINDOW_H
