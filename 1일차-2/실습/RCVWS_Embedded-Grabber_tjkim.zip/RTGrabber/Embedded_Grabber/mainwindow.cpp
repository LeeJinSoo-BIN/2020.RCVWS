#define RLEN  3724896
#define TLEN  81920
#define RCOL  964
#define RROW  1288
#define TCOL  256
#define TROW  320

#include "mainwindow.h"
#include "ui_mainwindow.h"

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    mDisplay = false;

    mRecording = false;
    mDecoding = false;

    num = 0;


    mCamera[0] = new CamThread(this);
    mCamera[1] = new CamThread(this);
    mCamera[0]->mAcqusition = false;

    mFilethread = new FileThread(this); //??
/*
    mThermalMac = "00:11:1c:03:57:1b";
    mThermalIp = "169.254.0.3";

    mRGBMac = "00:b0:9d:be:70:50";
    mRGBIp = "169.254.0.9";
*/
    mThermalMac = "00:11:1c:02:92:81";
    mThermalIp = "169.254.0.7";

    mRGBMac = "00:b0:9d:c9:b9:1c";
    mRGBIp = "169.254.0.5";


    qRegisterMetaType< cv::Mat >("cv::Mat");


    //connect(mCamera[0], SIGNAL(RGB_img( QImage )), this, SLOT(Display_RGB( QImage )));
    //connect(mCamera[0], SIGNAL(Thermal_img( QImage )), this, SLOT(Display_Thermal( QImage )));

    connect(mCamera[0], SIGNAL(ALL_IMAGE( cv::Mat, cv::Mat )), this, SLOT(Recording( cv::Mat, cv::Mat )));
    //connect(mCamera[0], SIGNAL(ALL_IMAGE( QImage, QImage )), this, SLOT(Recording( QImage, QImage )));

    connect(mCamera[0], SIGNAL(Disp( QImage )), this, SLOT(Display_Disp( QImage )));
    //connect(mCamera[0], SIGNAL(Disp( QImage, QImage )), this, SLOT(Display_Disp( QImage, QImage )));

    connect(mCamera[0], SIGNAL(Display(QImage,QImage)), this, SLOT(SlotDisplay( QImage, QImage )));

    connect(mFilethread, SIGNAL(EndDecode(int)), this, SLOT(EedDecodeSetText( int )));
}

MainWindow::~MainWindow()
{
    delete mCamera[0];
    delete mCamera[1];

    delete mFilethread;

    delete ui;
}

void MainWindow::on_m_connected_clicked()
{
    if (!mCamera[0]->mAcqusition){
        if (mCamera[0]->zConnect(mThermalMac.toStdString().c_str())) cout << "Connected 1!!!!" << endl;
        else cout << "Connected 1 failed....." << endl;
        if (mCamera[1]->zConnect(mRGBMac.toStdString().c_str())) cout << "Connected 2!!!!" << endl;
        else cout << "Connected 2 failed....." << endl;

        mCamera[0]->mDeviceGEV2 = mCamera[1]->mDeviceGEV;
        mCamera[0]->mStreamGEV2 = mCamera[1]->mStreamGEV;
        mCamera[0]->mPipeline2 = mCamera[1]->mPipeline;

        mCamera[0]->mAcqusition = true;
        mCamera[0]->start();

        ui->m_connected->setText("DisConnected");
    }
    else
    {
        mCamera[0]->mAcqusition = false;

        mCamera[0]->quit();
        mCamera[0]->wait();

        if (!mCamera[0]->zDisConnect()) cout << "Disconnection1 failed" << endl;
        if (!mCamera[1]->zDisConnect()) cout << "Disconnection2 failed" << endl;



        ui->m_connected->setText("Connected");
    }
}

void MainWindow::on_m_initialize_clicked()
{

    //lDevice_T = ConnectToDevice( "00:11:1c:02:92:81"  );
    //lDevice_T = ConnectToDevice( "00:11:1c:03:57:1b"  );
    //lDevice_R = ConnectToDevice( "00:b0:9d:c9:b9:1c"  );
    //lDevice_R = ConnectToDevice( "00:b0:9d:be:70:50"  );

    //Run Shell Script
    ShellScript();

    //Camera Ip congigure
    CamInitialize( mThermalMac.toStdString().c_str(), mThermalIp.toStdString().c_str() );
    CamInitialize( mRGBMac.toStdString().c_str(), mRGBIp.toStdString().c_str() );
}

void MainWindow::SlotDisplay(QImage rgb, QImage ther)
{
    if ( mDisplay )
    {
        ui->mRGB->setPixmap(QPixmap::fromImage(rgb));
        ui->mThermal->setPixmap(QPixmap::fromImage(ther));
    }
    else
    {
        QImage black = QImage(640, 512,QImage::Format_RGB888);
        black.fill(QColor(Qt::black).rgb());
        ui->mRGB->setPixmap( QPixmap::fromImage(black) );
        ui->mThermal->setPixmap( QPixmap::fromImage(black) );
    }
}


void MainWindow::Display_RGB( QImage rgb )
{
    if ( mDisplay )
    {
        ui->mRGB->setPixmap(QPixmap::fromImage(rgb));
    }
    else
    {
        QImage black = QImage(640, 512,QImage::Format_RGB888);
        black.fill(QColor(Qt::black).rgb());
        ui->mRGB->setPixmap( QPixmap::fromImage(black) );
    }
}

void MainWindow::Display_Thermal( QImage thermal )
{


    if ( mDisplay )
    {
        ui->mThermal->setPixmap(QPixmap::fromImage( thermal ));
    }
    else
    {
        QImage black = QImage(640, 512, QImage::Format_RGB888);
        black.fill(QColor(Qt::black).rgb());
        ui->mThermal->setPixmap( QPixmap::fromImage(black) );
    }
}

void MainWindow::Display_Disp( QImage Disp )
{
    if ( mDisplay )
    {
        ui->mDisp->setPixmap(QPixmap::fromImage( Disp.scaled(ui->mDisp->width(), ui->mDisp->height()) ));
    }
    else
    {
        QImage black = QImage(640, 512, QImage::Format_RGB888);
        black.fill(QColor(Qt::black).rgb());
        ui->mDisp->setPixmap( QPixmap::fromImage(black) );
    }
}
/*
void MainWindow::Display_Disp( QImage T, QImage R )
{
    if ( mDisplay )
    {
        mCamera[0]->mRectify = false;

        cv::Mat Thermal = mCamera[1]->qimage_to_mat_cpy(T, CV_8UC1);
        cv::Mat RGB = mCamera[1]->qimage_to_mat_cpy(R, CV_8UC3);


        //ui->mDisp->setPixmap(QPixmap::fromImage( Disp.scaled(ui->mDisp->width(), ui->mDisp->height()) ));
    }
    else
    {
        QImage black = QImage(640, 512, QImage::Format_RGB888);
        black.fill(QColor(Qt::black).rgb());
        ui->mDisp->setPixmap( QPixmap::fromImage(black) );
    }
}
*/
void MainWindow::ShellScript()
{
    if (system("echo 'v1s10nlab2019' |"
               " sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_rp_filter.sh"
               " --mode=0 --restartnetworkstack=yes"))
    {
        cout << "set_rp_filter failed" << endl;
    }

    if (system("echo 'v1s10nlab2019' | sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_socket_buffer_size.sh"))
    {
        cout << "set_soket_buffer failed" << endl;
    }
    else cout << "set_soket_buffer" << endl;

    if (system("echo 'v1s10nlab2019' | sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_usbfs_memory_size.sh"))
    {
        cout << "set_usbfs_memory_size failed" << endl;
    }
    else cout << "set_usbfs_memory_size" << endl;
/*
    if (system("cd /opt/pleora/ebus_sdk/linux-aarch64-arm/bin | echo 'v1s10nlab2019' | sudo service eBUSd stop") &&
            system("cd /opt/pleora/ebus_sdk/linux-aarch64-arm/bin | echo 'v1s10nlab2019' | sudo service eBUSd start"))
    {
        cout << "Valid license" << endl;
    }
    else cout << "InValid lincese" << endl;
    */

    system( "echo 'v1s10nlab2019' | sudo -S service eBUSd stop" );

    if (system( "echo 'v1s10nlab2019' | sudo -S service eBUSd start" ))
    {
        cout << "UnValid license" << endl;
    }
    else cout << "Valid license" << endl;
}

void MainWindow::CamInitialize(const char* Mac, const char* IpAdr)
{
    PvDeviceGEV* lDeviceSetIp = NULL;
    PvResult lResult;

    lResult = lDeviceSetIp->SetIPConfiguration( Mac, IpAdr, "255.255.0.0");

    if (!lResult.IsOK()) cout << lResult.GetCodeString().GetAscii() << endl;

}

void MainWindow::on_mDisplay_clicked()
{
    if (!mDisplay)
    {
        mDisplay = true;
        ui->mDisplay->setText("Display off");
    }
    else
    {
        mDisplay = false;
        ui->mDisplay->setText("Display On");
    }
}

void MainWindow::on_m_recording_clicked()
{
    if (mCamera[0]->mAcqusition && !mRecording)
    {
        //mFileStream = fopen("/media/rcvsejong/Samsung_T5/Recording/test.bin", "wb");
        mFilethread->mMode = 1;

        if (!mFilethread->isRunning())
            mFilethread->start();

        mRecording = true;
        ui->m_recording->setText("Recoding off");

    }
    else if (mRecording || !mCamera[0]->mAcqusition)
    {
        mFilethread->mMode = -1;

        mFilethread->quit();
        mFilethread->wait();

        mRecording = false;

        ui->m_recording->setText("Recording on");
    }

}
/*
void MainWindow::Recording( QImage RGB, QImage Theraml)
{
    if (mRecording)
    {

        RGB.save(QString("/media/rcvsejong/Samsung_T5/duotest/RGB/test_tj%1.jpg").arg(num));
        Theraml.save(QString("/media/rcvsejong/Samsung_T5/duotest/Thermal/test_tj%1d.jpg").arg(num));

        num++;
    }
}
*/

void MainWindow::Recording( cv::Mat RGB, cv::Mat Thermal)
{
    if (mRecording)
    {
        //printf("recoding !!\n");
/*
        cv::cvtColor(RGB, RGB, cv::COLOR_BGR2RGB);

        fwrite(RGB.data, 1, 3724896, mFileStream);
        fwrite(Thermal.data, 1, 81920, mFileStream);
*/
        //mFilethread->mRGB = RGB.clone();
        //mFilethread->mThermal = Thermal.clone();
        //RGB.copyTo(mFilethread->mRGB);
        //Thermal.copyTo(mFilethread->mThermal);

        mFilethread->mRGB = RGB.clone();
        mFilethread->mThermal = Thermal.clone();

        //memcpy( mFilethread->mRGB.data, RGB.data, RLEN );
        //memcpy( mFilethread->mThermal.data, Thermal.data, TLEN );

        mFilethread->mRecording = true;



        //num++;
    }
}

void MainWindow::on_mRGBMac_editingFinished()
{
    mRGBMac = ui->mRGBMAC->text();
}

void MainWindow::on_mRGBIP_editingFinished()
{
    mRGBIp = ui->mRGBIP->text();
}

void MainWindow::on_mThermalMac_editingFinished()
{
    mThermalMac = ui->mThermalMac->text();
}

void MainWindow::on_mThermalIP_editingFinished()
{
    mThermalIp = ui->mThermalIP->text();
}



void MainWindow::on_mDecoding_clicked()
{
/*
    if (!mDecoding)
    {
        mFileStream = fopen("/media/rcvsejong/Samsung_T5/Recording/test.bin", "rb");
        mDecoding = true;
        num = 0;
        ui->mDecoding->setText("Decoding...");
        Decoding();
    }
    else
    {
        mDecoding = false;
    }
*/

    if (!mDecoding)
    {
        mFilethread->mMode = 2;
        mFilethread->mDecoding = true;
        mFilethread->num = 0;

        if (!mFilethread->isRunning())
            mFilethread->start();

        ui->mDecoding->setText("Decoding...");
        //Decoding();
    }
    else
    {
        mFilethread->mMode = -1;

        mFilethread->quit();
        mFilethread->wait();

        ui->mDecoding->setText("Decoding STOP");

        mDecoding = false;
    }
}

void MainWindow::Decoding()
{
    if (mDecoding)
    {

        cv::Mat RGB(RCOL, RROW, CV_8UC3);
        cv::Mat Thermal(TCOL, TROW, CV_8UC1);

        while(1) {

            fread( RGB.data, sizeof(uchar), 3724896, mFileStream );
            fread( Thermal.data, sizeof(uchar), 81920, mFileStream );

            //cv::imwrite( cv::format("/media/rcvsejong/Samsung_T5/Recording/decoding/RGB/test_tj%d.jpg", num), RGB );
           // cv::imwrite( cv::format("/media/rcvsejong/Samsung_T5/Recording/decoding/Thermal/test_tj%d.jpg", num), Thermal);

            num++;

            if (feof(mFileStream)) break;

        }

        ui->mDecoding->setText("Complete");

        printf("Decoding END!!!!!!!!!!!!!!!!!!!!!\n");

        fclose( mFileStream );
    }
}

void MainWindow::EedDecodeSetText(int eof)
{
    if (eof)
        ui->mDecoding->setText("Complete");
}
