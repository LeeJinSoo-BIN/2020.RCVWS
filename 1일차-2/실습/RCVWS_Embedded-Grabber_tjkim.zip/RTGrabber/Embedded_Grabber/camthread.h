#ifndef CAMTHREAD_H
#define CAMTHREAD_H

#include "filethread.h"

#include <QObject>
#include <QThread>
#include <QImage>
#include <QWidget>
#include <QMutex>

#include <PvDevice.h>
#include <PvDeviceGEV.h>
#include <PvStream.h>
#include <PvStreamGEV.h>
#include <PvBuffer.h>
#include <PvBufferConverter.h>
#include <PvSystem.h>
#include <PvTypes.h>
#include <PvInterface.h>
#include <PvPixelType.h>
#include <PvBufferWriter.h>
#include <PvPipeline.h>
#include <PvBufferLib.h>
#include <PvPixelType.h>
#include <PvResult.h>



#include <opencv2/opencv.hpp>
#include <opencv2/core/utility.hpp>
#include "opencv2/cudastereo.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/calib3d/calib3d.hpp"

#include <iostream>
#include <list>
#include <stdlib.h>
#include <vector>
#include <iomanip>
#include <string>
#include <sstream>
#include <stdexcept>
#include <signal.h>
#include <ctime>




class CamThread : public QThread
{
    Q_OBJECT
public:
    explicit CamThread(QObject *parent = nullptr);


    bool mRectify;
    bool mAcqusition;
    PvDevice* mDevice;
    PvDeviceGEV* mDeviceGEV;
    PvStream* mStream;
    PvStreamGEV* mStreamGEV;
    PvPipeline* mPipeline;

    PvDeviceGEV* mDeviceGEV2;
    PvStreamGEV* mStreamGEV2;
    PvPipeline* mPipeline2;

    PvBuffer *lBuffer_T;
    PvBuffer *lBuffer_R;

    QMutex mMutex;


    bool zConnect(const char* Mac);

    bool zDisConnect();

    QImage mat_to_qimage_cpy(cv::Mat const &mat, QImage::Format format);
    cv::Mat qimage_to_mat_cpy(QImage const &img, int format);
    QImage Buffer_to_qimage_cpy(PvBuffer* const &buffer, QImage::Format format, uint32_t size);


private:
    void run();

    PvStreamGEV* ConfigureStream( PvDevice *aDevice, PvStream *aStream );
    PvDevice* ConnectToDevice( const char* aConnectionID);
    PvStream* OpenStream( const PvString &aConnectionID );
    PvPipeline* MakePipeline( PvDeviceGEV *aDevice, PvStream *aStream );
    void AcquireImages( PvDeviceGEV *aDevice_T, PvPipeline *mPipeline_T, PvStreamGEV *aStream_T, PvDeviceGEV *aDevice_R, PvPipeline *mPipeline_R, PvStreamGEV *aStream_R );

    void RectiParams();

    //vector<float> csv_read_row(istream &file, char delimiter);

    cv::Mat mCameraMatrixRR[2], mDistCoeffsRR[2],
        mRotationRR, mTranslationRR;
    cv::Mat mCameraMatrixRT[2], mDistCoeffsRT[2],
        mRotationRT, mTranslationRT;

    cv::Mat mR1_rr, mR2_rr, mP1_rr, mP2_rr, mQ_rr;
    cv::Mat mR1_rt, mR2_rt, mP1_rt, mP2_rt, mQ_rt;

    cv::Mat mHomography;

    cv::Mat mrtmap[2][2];

signals:
    //void RGB_img( QImage rgb );
    //void Thermal_img( QImage thermal );
    void Display( QImage rgb, QImage ther );
    void ALL_IMAGE( QImage RGB, QImage Thermal );
    void ALL_IMAGE( cv::Mat RGB, cv::Mat Thermal );
    void Disp( QImage qimg_disp );
    //void Disp( QImage qimg_t, QImage qimg_r );

public slots:
};

#endif // CAMTHREAD_H
