#ifndef FILETHREAD_H
#define FILETHREAD_H

#include <QObject>
#include <QThread>
#include <QMutex>


#include <opencv2/opencv.hpp>

class FileThread : public QThread
{
    Q_OBJECT
public:
    explicit FileThread(QObject *parent = nullptr);

    void run();

    bool mRecording;
    bool mDecoding;

    int mMode;
    int num;

    cv::Mat mRGB, mThermal;

    FILE* mFileStream;

signals:

    void EndDecode(int eof);


private:
    QMutex mMutex;

public slots:
};

#endif // FILETHREAD_H
