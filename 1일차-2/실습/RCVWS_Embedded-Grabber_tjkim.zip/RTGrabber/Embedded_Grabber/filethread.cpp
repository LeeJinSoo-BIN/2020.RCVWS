#include "filethread.h"

#define RLEN  3724896
#define TLEN  81920
#define RCOL  964
#define RROW  1288
#define TCOL  256
#define TROW  320

FileThread::FileThread(QObject *parent) : QThread(parent)
{
    mRecording = false;
    mDecoding = false;
    mMode = -1;
    num = 0;

    mRGB = cv::Mat(RCOL, RROW, CV_8UC3);
    mThermal = cv::Mat(TCOL, TROW, CV_8UC1);

    mFileStream = NULL;
}

void FileThread::run()
{
    if (mMode == 1){
        mFileStream = fopen("/media/rcvsejong/Samsung_T5/Recording/test2.bin", "wb");
        while( mMode == 1)
        {
            if (mRecording)
            {
                mRecording = false;

                //cv::cvtColor(mRGB, mRGB, cv::COLOR_BGR2RGB);

                mMutex.lock();

                fwrite(mRGB.data, 1, RLEN, mFileStream);
                fwrite(mThermal.data, 1, TLEN, mFileStream);

                mMutex.unlock();
            }
        }
    }
    else if ( mMode == 2)
    {
        if (mDecoding)
        {
            mFileStream = fopen("/media/rcvsejong/Samsung_T5/Recording/test.bin", "rb");

            cv::Mat RGB(RCOL, RROW, CV_8UC3);
            cv::Mat Thermal(TCOL, TROW, CV_8UC1);

            while(1) {

                mMutex.lock();

                fread( RGB.data, sizeof(uchar), RLEN, mFileStream );
                fread( Thermal.data, sizeof(uchar), TLEN, mFileStream );

                cv::imwrite( cv::format("/media/rcvsejong/Samsung_T5/Recording/decoding2/RGB2/test_tj%d.jpg", num), RGB );
                cv::imwrite( cv::format("/media/rcvsejong/Samsung_T5/Recording/decoding2/Thermal2/test_tj%d.jpg", num), Thermal);

                mMutex.unlock();

                num++;

                if (feof(mFileStream)) break;

            }

            emit EndDecode( feof( mFileStream ) );
            //printf("Decoding END!!!!!!!!!!!!!!!!!!!!!\n");

            fclose( mFileStream );
        }
    }
}
