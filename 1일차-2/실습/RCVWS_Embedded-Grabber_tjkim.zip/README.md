# Embedded-Grabber

## Specification
> - Camera
>   - Thermal : A35
>   - RGB : FL3-GE-13S2C
> - Embedded Board
>   - Jetson Xavier : Ubuntu 18.04 arm64
> - Lan Cable : CAT.7 SSTP Cable 3m
> - GPIO line : GPIO 12pin, GPIO 8pin Self-production(External Sync)
> - Plate : [사전 제공]
> - Battery : Li-Po 4S(14.4V) 65c 2500mAh -> 12~24V 
> - Camera SDK : eBus SDK 6.1.4 for Linux ARM
> - GUI/IDE : QT5

## 하드웨어 동기화 방법
- 동기화 신호는 29.97hz, 1us로 Thermal 에서 발생
- 동기화시 주의 사항 안내 : 동기화 신호를 받는 Trigger에서의 설정에 따라 동기화 시기가 달라진다.
   - 제안하는 시스템에서는 RGB의 동기화 모드를 Mode 14 (External 어쩌구 저쩌구)로 작동한다.
   - Mode 14는 동기화 신호가 도착시, 작업 중이라도 신호에 반응하여, 촬영을 재시작한다. exposure를 동기화 주기를 고려하지 않고 설정시 촬영이 완료되기 전에 동기화 신호로 촬영이 재시작되어 영상이 느려지는 현상이 발생한다.
   - 제안하는 시스템에서는 exposure를 15로 설정하

## eBus SDK 다운로드 방법
- https://supportcenter.pleora.com/s/topic/0TO340000004X6dGAE/ebus-sdk?tabset-25adb=81d66&tabset-0c866=2
- [eBUS SDK Package 6.1.4 for Linux ARM (Nvidia Jetson Nano, Jetson AGX Xavier, and Jetson TX2)
Supports both GigE Vision and USB3 Vision devices on Ubuntu 18.04 for ARM with Jetpack 4.2.](https://github.com/sejong-rcv/Embedded-Grabber/blob/master/eBUS_SDK_Jetson_linux-aarch64-arm-6.1.4-5137.zip)

## eBus SDK/QT Install
### QT
```
sudo apt-get update
sudo apt-get install build-essential
sudo apt-get install qt5-default qtcreator -y
```

### eBus SDK
```
sudo dpkg -i eBUS_SDK_<distribution_targeted>-<6.x.x>-<SDK build #>.deb
```
- (option) Optimal setting - picture

### library
- Project name(ex:Theraml_test2)을 오른쪽 클릭
- add library을 선택
![qt1](https://github.com/sejong-rcv/jetson/blob/master/qt1.png?raw=true)
![qt2](https://github.com/sejong-rcv/jetson/blob/master/qt2.png?raw=true)

#### Pleora Inc. Ebus SDK - include and lib location
- opt/pleora/ebus_sdk/linux-aarch64-arm/include
- opt/pleora/ebus_sdk/linux-aarch64-arm/lib

#### qmake 작성,.Pro 파일 통해 라이브러리 물려주기
.pro 파일에 아래의 코드를 넣어 주시면 됩니다.

아래의 코드는 opencv도 포함하고 있습니다.

```
INCLUDEPATH += \
        -I/usr/include/opencv2

LIBS += \
        -L/usr/lib -lopencv_core -lopencv_calib3d -lopencv_dnn -lopencv_features2d -lopencv_flann -lopencv_imgcodecs \
        -lopencv_highgui -lopencv_ml -lopencv_shape -lopencv_photo -lopencv_objdetect -lopencv_stitching -lopencv_superres \
        -lopencv_video -lopencv_videoio -lopencv_videostab

INCLUDEPATH += \
        -I/usr/include/ebus/include

LIBS += \
        -L/opt/pleora/ebus_sdk/linux-aarch64-arm/lib -lEbTransportLayerLib -lEbUtilsLib -lPtConvertersLib -lPtUtilsLib -lPvAppUtils \
        -lPvBase -lPvBuffer -lPvCameraBridge -lPvCoreGEV -lPvDevice -lPvGUI -lPvGenICam -lPvPersistence -lPvSerial -lPvStream \
        -lPvSystem -lPvTransmitter -lPvVirtualDevice -lSimpleImagingLib
```

### Excute eBus Player

```
opt/pleora/ebus_sdk/<distribution_targeted>/bin
sudo ./eBusPlayer
```

## eBus SDK를 이용한 카메라 영상 취득 흐름
- initialize -> Connect -> Display
   - initialize : ShellScript -> SetIP
   - Connect : 카메라 IP 설정 -> 카메라 설정 -> stream, pipeline -> Buffer 습득 ( 무한 루프 )
   - Display : Buffer 습득(무한 루프)에서 Buffer를 QImage로 변경하여 emit(SIGNAL)을 통해 QLabel을 통해 Display



### 카메라 초기화, initialize
```
void MainWindow::on_m_initialize_clicked()
{
    //Run Shell Script
    ShellScript();

    //Camera Ip congigure
    CamInitialize( mThermalMac[0].toStdString().c_str(), mThermalIp[0].toStdString().c_str() );
    CamInitialize( mRGBMac[0].toStdString().c_str(), mRGBIp[0].toStdString().c_str() );

    CamInitialize( mThermalMac[1].toStdString().c_str(), mThermalIp[1].toStdString().c_str() );
    CamInitialize( mRGBMac[1].toStdString().c_str(), mRGBIp[1].toStdString().c_str() );

}
```

#### 여러 대의 카메라를 실행 시키기 위한 설정, ShellScript
```
void MainWindow::ShellScript()
{
    if (system("echo 'v1s10nlab2019' |"
               " sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_rp_filter.sh"
               " --mode=0 --restartnetworkstack=yes"))
    {
        cout << "set_rp_filter failed" << endl;
    }

    if (system("echo 'v1s10nlab2019' | sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_socket_buffer_size.sh"))
    {
        cout << "set_soket_buffer failed" << endl;
    }
    else cout << "set_soket_buffer" << endl;

    if (system("echo 'v1s10nlab2019' | sudo -S /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/set_usbfs_memory_size.sh"))
    {
        cout << "set_usbfs_memory_size failed" << endl;
    }
    else cout << "set_usbfs_memory_size" << endl;

    if (system("echo 'v1s10nlab2019' | cd /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/; sudo -S service eBUSd stop") && system("echo 'v1s10nlab2019' | cd /opt/pleora/ebus_sdk/linux-aarch64-arm/bin/; sudo -S service eBUSd start"))
    {
        cout << "Valid license" << endl;
    }
    else cout << "InValid lincese" << endl;
}
```
- set_rp_filter.sh (rp=Reverser Path) : Reverser Path Filtering 값이 기본 1로 설정된 값을 0으로 변경하여, 통신을 위하여 filtering 기능을 꺼둠
- set_soket_buffer_size : 10485760 로 사이즈 증가
- set_usbf_memory_size : usb 통신 제한을 4000으로 확장
- service eBUSd stop/start : eBUS 라이센스 활성화, 작동시 상시 활성화 해줘야함

#### 카메라 IP 설정, CamInitialize

```
void MainWindow::CamInitialize(const char* Mac, const char* IpAdr)
{
    PvDeviceGEV* lDeviceSetIp = NULL;
    PvResult lResult;

    lResult = lDeviceSetIp->SetIPConfiguration( Mac, IpAdr, "255.255.0.0");

    if (!lResult.IsOK()) cout << lResult.GetCodeString().GetAscii() << endl;

}
```
- PvResult PvDeviceGEV::SetIPConfiguration	(	const PvString & 	aMACAddress,
const PvString & 	aIP,
const PvString & 	aSubnetMask = PvString( "255.255.255.0" ),
const PvString & 	aGateway = PvString( "0.0.0.0" ) 
)	
-해당 Macaddress의 IP를 aIP로 변경한다.

### Connect

#### 카메라 시작, run()
```
mCamera->start();
```
- start()는 QThread에서 쓰레드의 메인 함수인 run()을 작동시킨다.

```
void CamThread::run()
{
    cout << "RUN" << endl;

    AcquireImages();
}

```
#### 영상 취득, AcquireImages();

- Thermal, RGB 카메라 설정 및 stream stats
```
void CamThread::AcquireImages()
{

    //Thermal Setting
    PvGenParameterArray *lDeviceParams_T = mDeviceGEVt->GetParameters();
    
    lDeviceParams_T->SetEnumValue("SyncMode", 1); //SelfSyncMaster
    lDeviceParams_T->SetEnumValue("NUCMode", 0);
    ///////////////////////////////////////////////
    
    //////////////////RGB Setting
    PvGenParameterArray *lDeviceParams_R = mDeviceGEVr->GetParameters();
    
    lDeviceParams_R->SetEnumValue("ExposureAuto",0);
    lDeviceParams_R->SetFloatValue("ExposureTime",1050);
    
    lDeviceParams_R->SetEnumValue("TriggerMode",1);   //Sync, Trigger Mode
    lDeviceParams_R->SetEnumValue("TriggerSource",3); //GPIO Mode 3

    lDeviceParams_R->SetIntegerValue("OffsetX",0);
    lDeviceParams_R->SetIntegerValue("OffsetY",0);
    lDeviceParams_R->SetIntegerValue("Width",1288);
    lDeviceParams_R->SetIntegerValue("Height",964);
    ////////////////////////////////////////////////

    cout << "Setting Complete" << endl;

    // Map the GenICam AcquisitionStart and AcquisitionStop commands
    PvGenCommand *lStart_T = dynamic_cast<PvGenCommand *>( lDeviceParams_T->Get( "AcquisitionStart" ) );
    PvGenCommand *lStop_T = dynamic_cast<PvGenCommand *>( lDeviceParams_T->Get( "AcquisitionStop" ) );

    PvGenCommand *lStart_R = dynamic_cast<PvGenCommand *>( lDeviceParams_R->Get( "AcquisitionStart" ) );
    PvGenCommand *lStop_R = dynamic_cast<PvGenCommand *>( lDeviceParams_R->Get( "AcquisitionStop" ) );

    // Get stream parameters
    PvGenParameterArray *lStreamParams_T = mStreamGEVt->GetParameters();
    PvGenParameterArray *lStreamParams_R = mStreamGEVr->GetParameters();

    // Map a few GenICam stream stats counters
    PvGenFloat *lFrameRate_T = dynamic_cast<PvGenFloat *>( lStreamParams_T->Get( "AcquisitionRate" ) );
    PvGenFloat *lBandwidth_T = dynamic_cast<PvGenFloat *>( lStreamParams_T->Get( "Bandwidth" ) );
    PvGenFloat *lFrameRate_R = dynamic_cast<PvGenFloat *>( lStreamParams_R->Get( "AcquisitionRate" ) );
    PvGenFloat *lBandwidth_R = dynamic_cast<PvGenFloat *>( lStreamParams_R->Get( "Bandwidth" ) );

    // Enable streaming and send the AcquisitionStart command
    cout << "Enabling streaming and sending AcquisitionStart command." << endl;
    mDeviceGEVt->StreamEnable();
    lStart_T->Execute();

    mDeviceGEVr->StreamEnable();
    lStart_R->Execute();

    char lDoodle[] = "|\\-|-/";
    int lDoodleIndex = 0;
    double lFrameRateVal_T = 0.0;
    double lBandwidthVal_T = 0.0;
```

- Buffer 습득
```
    cout << "Acquire image" << endl;
    
    cout << endl << "<Start>" << endl;

    while(mAcqusition)
    {
        cout << "OK" << endl;
        
        PvBuffer *lBuffer_T = NULL; //영상 정보가 담기는 Buffer
        PvBuffer *lBuffer_R = NULL;

        PvResult lOperationResult_T;   //Buffer 습득시 생기는 에러 처리를 위한 변수
        PvResult lOperationResult_R;

        PvResult lResult_T;
        PvResult lResult_R ;

        if ((mStreamGEVt != NULL) && mStreamGEVt->IsOpen() &&
                (mPipelineT != NULL) && mPipelineT->IsStarted())
        {
            cout<<"Get Thermal"<<endl;
            lResult_T = mPipelineT->RetrieveNextBuffer( &lBuffer_T, 0xFFFFFFFF, &lOperationResult_T); //Thermal 영상 습득
            //cout << lResult_T.GetCodeString().GetAscii() << endl;

        }
        else{
            cout<<"Pass Thermal"<<endl;
            continue;
        }


        if ((mStreamGEVr != NULL) && mStreamGEVr->IsOpen() &&
                (mPipelineR != NULL) && mPipelineR->IsStarted())
        {
            cout<<"Get RGB"<<endl;
            lResult_R = mPipelineR->RetrieveNextBuffer( &lBuffer_R, 0xFFFFFFFF, &lOperationResult_R );   //RGB 영상 
            //cout << lResult_T.GetCodeString().GetAscii() << endl;
        }
        else{
            cout<<"Pass RGB"<<endl;
            continue;
        }
        
        // 영상 습득과 무한 루프 속도가 맞지 않아 Buffer가 담기지 않은 채로 처리 되는 것을 방지하고자 하는 if 문
        if ( lResult_T.IsOK() && lResult_R.IsOK() && lBuffer_T->GetImage()->GetWidth() != 0 && lBuffer_R->GetImage()->GetWidth() != 0 )
        {
            cout<<"Pass"<<endl;
            if (  lOperationResult_R.IsOK() && lOperationResult_T.IsOK() )
            {
                cout<<"Pass"<<endl;

         ///// 카메라와 스트림 정보
                lFrameRate_T->GetValue( lFrameRateVal_T );
                lBandwidth_T->GetValue( lBandwidthVal_T );

                lFrameRate_R->GetValue( lFrameRateVal_R );
                lBandwidth_R->GetValue( lBandwidthVal_R );


                cout << fixed << setprecision( 1 );
                cout << lDoodle[ lDoodleIndex ];

                BufferType( lBuffer_T );
                BufferType( lBuffer_T2 );

                cout << "  " << lFrameRateVal_T << " FPS  " << ( lBandwidthVal_T / 1000000.0 ) << " Mb/s   \r" << endl;
                cout << "  " << lFrameRateVal_R << " FPS  " << ( lBandwidthVal_R / 1000000.0 ) << " Mb/s   \r";


                //emit Frame( lFrameRateVal_T, lFrameRateVal_R );
         ////////

         /////// Thermal Buffer -> cv::Mat(CV_8UC1) -> QImage(Grayscale8)
                uint32_t size_T = lBuffer_T->GetSize();
                
                cv::Mat MatThermal(256, 320, CV_8UC1);
                cv::Mat MatThermal_resize(512, 640, CV_8UC1);
                memcpy(MatThermal.data, lBuffer_T->GetDataPointer(), size_T);

                cout << "thermal ok" <<endl;
                cv::resize(MatThermal, MatThermal_resize, cv::Size(640, 512));

                QImage qimg_t(MatThermal_resize.data, MatThermal_resize.cols, MatThermal_resize.rows, MatThermal_resize.step, QImage::Format_Grayscale8);
               // QImage qimg_t(lBuffer_T->GetImage()->GetHeight(), lBuffer_T->GetImage()->GetWidth(), QImage::Format_Grayscale8);

                emit Thermal_img( qimg_t );  //Display Signal

           ////////


           ////// RGB Buffer -> cv::Mat(8UC1) -> cvtcolort(Bayer2BGR) (8UC3) -> QImage(RGB888)
                uint32_t size_R = lBuffer_R->GetSize();

                cv::Mat Img_R(964, 1288, CV_8UC3);
                cv::Mat Img_R_1(964, 1288, CV_8UC1);

                cv::Mat Img_R_resize(512, 640, CV_8UC3);
                memcpy(Img_R_1.data, lBuffer_R->GetDataPointer(), size_R);
                //memcpy(Img_R.data, new_RGB->GetDataPointer(), size_R);

                cv::cvtColor(Img_R_1,Img_R, cv::COLOR_BayerGB2BGR);

                cv::resize(Img_R, Img_R_resize, cv::Size(640, 512));

                QImage qimg_r(Img_R_resize.data, Img_R_resize.cols, Img_R_resize.rows, Img_R_resize.step, QImage::Format_RGB888);

                emit RGB_img( qimg_r ); //Display Signal

            //////

                //emit ALL_IMAGE( qimg_r, qimg_t, qimg_r2, qimg_t2 );   //Recording signal


                ///// Release Buffer
                lResult_T = mPipelineT->ReleaseBuffer(lBuffer_T);
                if (!lResult_T.IsOK()) cout << "Can't ReleaseBuffer" << endl;

                lResult_R = mPipelineR->ReleaseBuffer(lBuffer_R);
                if (!lResult_R.IsOK()) cout << "Can't ReleaseBuffer" << endl;
                
                //````````

                //~~~~~~~

            }
            else
            {
                // Non OK operational result
                cout << lDoodle[ lDoodleIndex ] << " operational_T ERROR!! " << lOperationResult_T.GetCodeString().GetAscii() << "\r";
                cout << lDoodle[ lDoodleIndex ] << " operational_R ERROR!! " << lOperationResult_R.GetCodeString().GetAscii() << "\r";
            }

        }
        else
        {
            // Retrieve buffer failure
           cout << lDoodle[ lDoodleIndex ] << " Retrieve buffer ERROR! " << lResult_T.GetCodeString().GetAscii()
                 << " " << lResult_R.GetCodeString().GetAscii() << "\r";
         //   cout << lDoodle[ lDoodleIndex ] << " Retrieve buffer ERROR! " << lResult_T.GetCodeString().GetAscii()
           //      << " " << lResult_R.GetCodeString().GetAscii() << "\r";
        }

        ++lDoodleIndex %= 6;
    }


    //---------------------------------------------------------------------
    //PvGetChar(); // Flush key buffer for next stop.
    cout << endl << endl;

    // Tell the device to stop sending images.
    cout << "Sending AcquisitionStop command to the device" << endl;
    lStop_T->Execute();
    lStop_R->Execute();

    // Disable streaming on the device
    cout << "Disable streaming on the controller." << endl;
    mDeviceGEVt->StreamDisable();
    mDeviceGEVr->StreamDisable();

    // Abort all buffers from the stream and dequeue
    cout << "Aborting buffers still in stream" << endl;
    mStreamGEVt->AbortQueuedBuffers();
    mStreamGEVr->AbortQueuedBuffers();


}

```

```
bool CamThread::zConnect(const char* Mac)
{
    mDevice = ConnectToDevice(Mac);

    mDeviceGEV = dynamic_cast<PvDeviceGEV *>( mDevice );

    if ( mDevice != NULL )
    {
        mStream = OpenStream( mDeviceGEV->GetIPAddress() );

        if (mStream != NULL)
        {
            mStreamGEV = ConfigureStream(mDevice, mStream);

            mPipeline = MakePipeline( mDeviceGEV, mStream );

            if ( mPipeline == NULL ) return false;

        }
        else
        {
            cout << "Disable to stream from camera" << endl;

            return false;
        }
    }
    else
    {
        cout << "Disable to connect to camera" << endl;

        return false;
    }

    return true;
}
```
- Connect Device
```
PvDevice* CamThread::ConnectToDevice( const char* aConnectionID)
{
    PvDevice *lDevice;
    PvResult lResult;

    // Connect to the GigE Vision or USB3 Vision device
    cout << "Connecting to device." << endl;
    lDevice = PvDevice::CreateAndConnect( aConnectionID, &lResult );
    if ( lDevice == NULL )
    {
        cout << "Unable to connect to device: "
        << lResult.GetCodeString().GetAscii()
        << " ("
        << lResult.GetDescription().GetAscii()
        << ")" << endl;
    }


    return lDevice;
}
```

- Stream Device

```
PvStream* CamThread::OpenStream( const PvString &aConnectionID )
{카메라 IP 설정 -> 카메라 설정 -> stream, pipeline -> Buffer 습득
    PvStream *lStream;
    PvResult lResult;

    // Open stream to the GigE Vision or USB3 Vision device
    cout << "Opening stream from device." << endl;
    lStream = PvStream::CreateAndOpen( aConnectionID, &lResult );
    if ( lStream == NULL )
    {
        cout << "Unable to stream from device. "
            << lResult.GetCodeString().GetAscii()
            << " ("
            << lResult.GetDescription().GetAscii()
            << ")"
            << endl;
    }

    return lStream;
}

```

- Make Pipeline 
```
PvStreamGEV* CamThread::ConfigureStream( PvDevice *aDevice, PvStream *aStream  )
{
    PvStreamGEV* lStreamGEV = NULL;
    // If this is a GigE Vision device, configure GigE Vision specific streaming parameters
    PvDeviceGEV* lDeviceGEV = dynamic_cast<PvDeviceGEV *>( aDevice );
    if ( lDeviceGEV != NULL )
    {
        lStreamGEV = static_cast<PvStreamGEV *>( aStream );

        // Negotiate packet size
        lDeviceGEV->NegotiatePacketSize();

        // Configure device streaming destination
        lDeviceGEV->SetStreamDestination( lStreamGEV->GetLocalIPAddress(), lStreamGEV->GetLocalPort() );
    }

    return lStreamGEV;
}

PvPipeline *CamThread::MakePipeline( PvDeviceGEV *aDevice, PvStream *aStream)
{

    PvResult lResult;

    // Reading payload size from device
    uint32_t lSize = aDevice->GetPayloadSize();

   PvPipeline *mPipeline;

    mPipeline = new PvPipeline(aStream); //lStream??

    mPipeline->SetBufferSize(static_cast<uint32_t>(lSize));
    mPipeline->SetBufferCount( 16 );
    lResult = mPipeline->Start();
    
    if (!lResult.IsOK())
    {
        cout << "Unable to start pipeline" << endl;
    }

    PvGenBoolean *lRequestMissingPackets = dynamic_cast<PvGenBoolean *>(aStream->GetParameters()->GetBoolean("RequestMissingPackets"));
    if ((lRequestMissingPackets != NULL) && lRequestMissingPackets->IsAvailable())
    {
        // Disabling request missing packets.
        lRequestMissingPackets->SetValue(false);
    }

    return mPipeline;

}

```


### Display
Buffer -> 영상화 -> emit -> Signal -> Slot -> Display

### Disconnetion
Buffer 제거 -> Pipeline 제거 -> stream 제거 -> device 연결 해제, 제거




