function [interp, outputView, fillValues] = ...
    parseInputsCalibrated(image1, stereoParams, varargin)

validateStereoParameters(stereoParams);

if isempty(coder.target)
    [interp, outputView, fillValues] = ...
        vision.internal.inputValidation.parseUndistortRectifyInputsMatlab(...
        'rectifyStereoImages', image1, @validateOutputViewPartial, varargin{:});
else
    [interp, outputView, fillValues] = ...
        vision.internal.inputValidation.parseUndistortRectifyInputsCodegen(...
        image1, 'rectifyStereoImages', 'valid', varargin{:});
end
fillValues = vision.internal.inputValidation.scalarExpandFillValues(...
    fillValues, image1);
end
function [tform1, tform2, interp, outputView, fillValues] = ...
    parseInputsUncalibrated(I1, t1, t2, varargin)

validateTransform(t1, 'tform1');
validateTransform(t2, 'tform2');

if isnumeric(t1)
    tform1 = projective2d(t1);
    tform2 = projective2d(t2);
else
    tform1 = t1;
    tform2 = t2;
end

if isempty(coder.target)
    [interp, outputView, fillValues] = ...
        vision.internal.inputValidation.parseUndistortRectifyInputsMatlab(...
        'rectifyStereoImages', I1, @validateOutputViewPartial, varargin{:});
else
    [interp, outputView, fillValues] = ...
        vision.internal.inputValidation.parseUndistortRectifyInputsCodegen(...
        I1, 'rectifyStereoImages', 'valid', varargin{:});
end
end
%--------------------------------------------------------------------------
function TF = validateTransform(tform, varName)
validateattributes(tform, {'double', 'single', 'projective2d'}, {}, ...
    mfilename, varName); %#ok<EMCA>

if ~isa(tform, 'projective2d')
    validateattributes(tform, {'double', 'single'}, ...
        {'real', 'nonsparse', 'size', [3, 3]}, mfilename, varName); %#ok<EMCA>
end

TF = true;
end
%--------------------------------------------------------------------------
function TF = validateStereoParameters(params)
validateattributes(params, {'stereoParameters'}, ...
    {'scalar'}, mfilename, 'stereoParams'); %#ok<EMCA>
TF = true;
end
%--------------------------------------------------------------------------
function outputView = validateOutputViewPartial(outputView)
outputView = ...
    validatestring(outputView, {'full', 'valid'}, mfilename, 'OutputView'); %#ok<EMCA>
end
%--------------------------------------------------------------------------
function [J1, J2] = rectifyUncalibrated(I1, I2, tform1, tform2, interp, ...
    fillValues, outputView)
% Compute the transformed location of image corners.
outPts = zeros(8, 2);
numRows = size(I1, 1);
numCols = size(I1, 2);
inPts = [1, 1; 1, numRows; numCols, numRows; numCols, 1];
outPts(1:4,1:2) = transformPointsForward(tform1, inPts);
numRows = size(I2, 1);
numCols = size(I2, 2);
inPts = [1, 1; 1, numRows; numCols, numRows; numCols, 1];
outPts(5:8,1:2) = transformPointsForward(tform2, inPts);

xSort   = sort(outPts(:,1));
ySort   = sort(outPts(:,2));
xLim = zeros(1, 2);
yLim = zeros(1, 2);
if strcmp(outputView, 'valid')
    % Compute the common rectangular area of the transformed images.
    xLim(1) = ceil(xSort(4)) - 0.5;
    xLim(2) = floor(xSort(5)) + 0.5;
    yLim(1) = ceil(ySort(4)) - 0.5;
    yLim(2) = floor(ySort(5)) + 0.5;
else % full
    xLim(1) = ceil(xSort(1)) - 0.5;
    xLim(2) = floor(xSort(8)) + 0.5;
    yLim(1) = ceil(ySort(1)) - 0.5;
    yLim(2) = floor(ySort(8)) + 0.5;
end

width   = xLim(2) - xLim(1) - 1;
height  = yLim(2) - yLim(1) - 1;
outputViewRef = imref2d([height, width], xLim, yLim);

% Transform the images.
J1 = imwarp(I1, tform1, interp, 'OutputView', outputViewRef, 'FillValues', ...
    fillValues);
J2 = imwarp(I2, tform2, interp, 'OutputView', outputViewRef, 'FillValues', ...
    fillValues);
end