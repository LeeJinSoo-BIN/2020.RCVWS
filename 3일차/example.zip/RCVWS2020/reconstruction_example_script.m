clear; clc; close all; imtool close all;

rgbLPath = "./sample/rgbL/RGB_L_0000000.png";
rgbRPath = "./sample/rgbR/RGB_R_0000000.png";

rgbL = imread(rgbLPath);
rgbR = imread(rgbRPath);

rgbL = imresize(rgbL, [512 640]);
rgbR = imresize(rgbR, [512 640]);

imshowpair(rgbL, rgbR, 'montage')

paramPath = "./parameters/Params(MatAPP)/RGB/stereo/stereoParams.mat";
params = load(paramPath);

[rgbL_rec1, rgbR_rec1] = rectifyStereoImages(rgbL(:,:,1), rgbR(:,:,1), params.stereoParams);
[rgbL_rec2, rgbR_rec2] = rectifyStereoImages(rgbL(:,:,2), rgbR(:,:,2), params.stereoParams);
[rgbL_rec3, rgbR_rec3] = rectifyStereoImages(rgbL(:,:,3), rgbR(:,:,3), params.stereoParams);

rgbL_rec = cat(3, rgbL_rec1, rgbL_rec2, rgbL_rec3);
rgbR_rec = cat(3, rgbR_rec1, rgbR_rec2, rgbR_rec3);

rgbL_rec_gray = rgb2gray(rgbL_rec);
rgbR_rec_gray = rgb2gray(rgbR_rec);

imshowpair(rgbL_rec, rgbR_rec, 'montage')

disparityRange = [0 96];
disparityMap = disparitySGM(rgbL_rec_gray,rgbR_rec_gray,'DisparityRange',disparityRange,'UniquenessThreshold',0);
imagesc(disparityMap)

points3D = reconstructScene(disparityMap, params.stereoParams);
points3D = points3D ./ 1000;
ptCloud = pointCloud(points3D, 'Color', rgbL_rec);

% Create a streaming point cloud viewer
player3D = pcplayer([-3, 3], [-3, 3], [0, 8], 'VerticalAxis', 'y', ...
    'VerticalAxisDir', 'down');

% Visualize the point cloud
view(player3D, ptCloud);
